
import { GoogleGenAI, Type } from "@google/genai";
import { PortalFolder, PortalApp } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Flattens the nested folder structure for easier searching by the AI.
 */
const flattenApps = (folder: PortalFolder, path: string[] = []): { app: PortalApp, path: string[] }[] => {
  let apps: { app: PortalApp, path: string[] }[] = folder.applications.map(app => ({
    app,
    path: [...path, folder.name]
  }));
  
  folder.subfolders.forEach(sub => {
    apps = [...apps, ...flattenApps(sub, [...path, folder.name])];
  });
  
  return apps;
};

export const getAIAssistance = async (query: string, data: PortalFolder) => {
  const allApps = flattenApps(data);
  const context = allApps.map(item => ({
    id: item.app.id,
    name: item.app.name,
    description: item.app.description,
    path: item.path.join(' > ')
  }));

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `User is looking for an application. Query: "${query}"
    Available applications context: ${JSON.stringify(context)}`,
    config: {
      systemInstruction: "You are a helpful portal assistant. Based on the user's query and the available applications, suggest the most relevant app. If multiple are relevant, list them. If none are relevant, say so politely. Always include the 'path' so the user knows where it is.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          suggestion: { type: Type.STRING, description: "A friendly explanation of why these apps match." },
          matchedIds: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "IDs of the matched applications."
          }
        },
        required: ["suggestion", "matchedIds"]
      }
    }
  });

  return JSON.parse(response.text);
};
